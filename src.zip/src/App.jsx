import { Routes, Route } from "react-router-dom";
import LandingPage from "./Landing/pages/LandingPage.jsx";
import SearchResultsPage from "./Search/pages/SearchResultsPage.jsx";
import FlightsPage from "./Flight/pages/FlightsBookingPage.jsx";
import CarRentalPage from "./CarRental/pages/CarRentalPage.jsx";
import AttractionsHomePage from "./Attractions/pages/AttractionsHomePage.jsx";
import AttractionsCityPage from "./Attractions/pages/AttractionsCityPage.jsx";
import AttractionDetailPage from "./Attractions/pages/AttractionDetailPage.jsx";
import TaxiPage from "./Taxi/pages/TaxiPage.jsx";
import HotelDetailPage from "./Landing/pages/HotelDetailPage.jsx";
import CheckoutPage from "./Auth/pages/CheckoutPage.jsx";
import LoginPage from "./Auth/pages/LoginPage.jsx";
import RegisterPage from "./Auth/pages/RegisterPage.jsx";
import ProfilePage from "./Auth/pages/ProfilePage.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/search" element={<SearchResultsPage />} />
      <Route path="/flights" element={<FlightsPage />} />
      <Route path="/car-rental" element={<CarRentalPage />} />
      <Route path="/attractions" element={<AttractionsHomePage />} />
      <Route
        path="/attractions/detail/:id"
        element={<AttractionDetailPage />}
      />
      <Route path="/attractions/:citySlug" element={<AttractionsCityPage />} />
      <Route path="/taxi" element={<TaxiPage />} />
      <Route path="/hotel/:id" element={<HotelDetailPage />} />
      <Route path="/checkout/:id" element={<CheckoutPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/profile" element={<ProfilePage />} />
    </Routes>
  );
}
