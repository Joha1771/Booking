import { supabase } from "../../lib/supabase.js";
import {
  getAttractionCities as getFallbackAttractionCities,
  getAttractionCityByName,
  getAttractionCityBySlug,
  getFallbackAttractions,
  getDiscoveryCards as getFallbackDiscoveryCards,
  slugifyAttractionCity,
} from "./attractionsData.js";

function isMissingTableError(error) {
  if (!error) return false;
  return (
    error.code === "42P01" ||
    /does not exist|could not find the table|column .* does not exist/i.test(
      error.message || "",
    )
  );
}

function normalizeAttractionRow(row, index = 0) {
  const cityData =
    getAttractionCityByName(row.city) || getAttractionCityBySlug(row.city_slug);
  const imageBase =
    row.id ||
    `${slugifyAttractionCity(row.city || cityData?.city || "attraction")}-${index}`;
  const rating = Number.parseFloat(row.rating ?? 4.4);
  const reviewsCount = Number(
    row.reviews_count ?? row.reviews ?? 900 + index * 37,
  );
  const price = Number(row.price ?? row.price_from ?? 0);
  const originalPrice = Number(
    row.original_price ?? (price > 0 ? Math.round(price * 1.12) : 0),
  );

  return {
    id: row.id || `${imageBase}`,
    city_slug:
      row.city_slug || cityData?.slug || slugifyAttractionCity(row.city),
    city: row.city || cityData?.city || "",
    country: row.country || cityData?.country || "",
    name: row.name || row.title || "Вариант досуга",
    category: row.category || "История",
    short_description:
      row.short_description ||
      row.description ||
      `Популярное развлечение в городе ${row.city || cityData?.city || ""}.`,
    rating: Number.isFinite(rating) ? rating : 4.4,
    rating_label:
      row.rating_label ||
      (rating >= 4.7
        ? "Потрясающе"
        : rating >= 4.5
          ? "Превосходно"
          : "Очень хорошо"),
    reviews_count: Number.isFinite(reviewsCount) ? reviewsCount : 0,
    price,
    original_price: originalPrice,
    duration_hours: Number(row.duration_hours ?? 2),
    duration_label:
      row.duration_label || `${Number(row.duration_hours ?? 2)} ч.`,
    image_url:
      row.image_url ||
      cityData?.heroImage ||
      `https://picsum.photos/seed/${imageBase}-main/440/440`,
    gallery_images:
      row.gallery_images ||
      cityData?.gallery ||
      Array.from(
        { length: 4 },
        (_, galleryIndex) =>
          `https://picsum.photos/seed/${imageBase}-thumb-${galleryIndex + 1}/216/216`,
      ),
    free_cancel: row.free_cancel ?? true,
    available_today: row.available_today ?? true,
    bestseller_rank: row.bestseller_rank ?? null,
    is_genius: row.is_genius ?? false,
  };
}

function filterFallbackByQuery(items, query) {
  if (!query) return items;
  const normalizedQuery = query.toString().trim().toLowerCase();
  if (!normalizedQuery) return items;

  return items.filter((item) => {
    const haystack =
      `${item.name} ${item.city} ${item.category} ${item.short_description}`.toLowerCase();
    return haystack.includes(normalizedQuery);
  });
}

function normalizeCityRow(row) {
  // attraction_cities table has: name, country, region, variants, image_url
  const cityName = row.name || row.city || "Город";
  const slug = row.city_slug || row.slug || slugifyAttractionCity(cityName);

  return {
    slug,
    name: cityName,
    city: cityName,
    country: row.country || "",
    region: row.region || "Все",
    image_url: row.image_url || `https://picsum.photos/seed/${slug}/900/700`,
    variants: Number(row.variants ?? row.variants_count ?? 0),
    heroTitle: `Варианты досуга в городе ${cityName}`,
    heroSubtitle: `Популярные развлечения, билеты и экскурсии в городе ${cityName}.`,
    discoveryText: `Лучшие идеи досуга в городе ${cityName}.`,
    sortOrder: Number(row.sort_order ?? 999),
  };
}

function normalizeCollectionRow(row, index = 0) {
  return {
    id: row.id || `collection-${index + 1}`,
    title: row.title || "Подборка",
    subtitle: row.subtitle || "Лучшие развлечения для выбранной категории.",
    category: row.category || "История",
    citySlug: row.city_slug || "all",
    totalItems: Number(row.total_items ?? 0),
    image:
      row.image_url ||
      `https://picsum.photos/seed/collection-${index + 1}/1200/760`,
    sortOrder: Number(row.sort_order ?? 999),
  };
}

async function fetchSupabaseAttractions({ city, category, query, limit }) {
  let attractionsQuery = supabase
    .from("attractions")
    .select("*")
    .order("rating", { ascending: false });

  if (category) attractionsQuery = attractionsQuery.eq("category", category);
  if (query) attractionsQuery = attractionsQuery.ilike("name", `%${query}%`);

  if (!city || city === "all") {
    const { data, error } = await attractionsQuery.limit(limit);
    return { data, error };
  }

  const fallbackCity =
    getAttractionCityBySlug(city)?.city || getAttractionCityByName(city)?.city;
  const slugCandidate = slugifyAttractionCity(city);
  const attempts = [
    { column: "city_slug", value: slugCandidate },
    fallbackCity ? { column: "city", value: fallbackCity } : null,
    fallbackCity && fallbackCity !== city
      ? { column: "city", value: city }
      : null,
  ].filter(Boolean);

  let lastError = null;

  for (const attempt of attempts) {
    const { data, error } = await attractionsQuery
      .eq(attempt.column, attempt.value)
      .limit(limit);

    if (error) {
      lastError = error;
      if (isMissingTableError(error)) continue;
      return { data: null, error };
    }

    if (data?.length) return { data, error: null };
  }

  return { data: [], error: lastError };
}

export async function getAttractions({ city, category, limit = 12 } = {}) {
  const resolvedCity = city
    ? getAttractionCityBySlug(city)?.city || city
    : null;
  const { data, error } = await fetchSupabaseAttractions({
    city,
    category,
    limit,
  });

  if (error) console.error("getAttractions:", error.message);
  if (!data?.length) {
    return getFallbackAttractions({
      city: resolvedCity || city,
      category,
      limit,
    });
  }

  return data.map(normalizeAttractionRow).slice(0, limit);
}

export async function searchAttractions({
  query,
  city,
  category,
  limit = 24,
} = {}) {
  const resolvedCity = city
    ? getAttractionCityBySlug(city)?.city || city
    : null;
  const { data, error } = await fetchSupabaseAttractions({
    city,
    category,
    query,
    limit,
  });

  if (error) console.error("searchAttractions:", error.message);
  if (!data?.length) {
    return filterFallbackByQuery(
      getFallbackAttractions({ city: resolvedCity || city, category }),
      query,
    ).slice(0, limit);
  }

  return data.map(normalizeAttractionRow).slice(0, limit);
}

export async function getAttractionCities() {
  const { data, error } = await supabase
    .from("attraction_cities")
    .select("*")
    .order("variants", { ascending: false });

  if (!error && data?.length) {
    return data.map(normalizeCityRow);
  }

  if (error) console.error("getAttractionCities:", error.message);
  return getFallbackAttractionCities();
}

export async function getAttractionDiscoveryCards() {
  const { data, error } = await supabase
    .from("attraction_collections")
    .select("*")
    .order("sort_order", { ascending: true });

  if (!error && data?.length) {
    return data.map(normalizeCollectionRow);
  }

  if (error && !isMissingTableError(error)) {
    console.error("getAttractionDiscoveryCards:", error.message);
  }

  return getFallbackDiscoveryCards();
}

export async function getAttractionById(id) {
  const { data, error } = await supabase
    .from("attractions")
    .select("*")
    .eq("id", id)
    .single();
  if (error) console.error("getAttractionById:", error.message);
  if (!data) return null;
  return normalizeAttractionRow(data);
}

export async function getAttractionBySlug(slug) {
  const { data, error } = await supabase
    .from("attractions")
    .select("*")
    .eq("slug", slug)
    .single();
  if (error) console.error("getAttractionBySlug:", error.message);
  if (!data) return null;
  return normalizeAttractionRow(data);
}

export {
  getAttractionCityBySlug,
  getAttractionCityByName,
  getAttractionDiscoveryCards as getDiscoveryCards,
  slugifyAttractionCity,
};
