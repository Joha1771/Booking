const CATEGORY_META = {
  Круизы: {
    durationLabel: "1 ч. – 1 ч. 20 мин.",
    hours: 1.2,
    blurb: "Водная прогулка с лучшими видами на главные достопримечательности.",
  },
  Музеи: {
    durationLabel: "2 ч. – 3 ч.",
    hours: 2.5,
    blurb:
      "Билет с удобным входом и временем на самостоятельное знакомство с коллекцией.",
  },
  История: {
    durationLabel: "2 ч. – 4 ч.",
    hours: 3,
    blurb:
      "Маршрут с рассказом о культовых местах, архитектуре и городской истории.",
  },
  "Смотровые площадки": {
    durationLabel: "1 ч. – 2 ч.",
    hours: 1.5,
    blurb:
      "Возможность увидеть город с высоты и выбрать лучший тайм-слот для посещения.",
  },
  Семейные: {
    durationLabel: "2 ч. – 5 ч.",
    hours: 3.5,
    blurb:
      "Идеальный вариант для поездки с детьми, с гибкими условиями посещения.",
  },
  "Однодневные поездки": {
    durationLabel: "6 ч. – 10 ч.",
    hours: 8,
    blurb:
      "Насыщенный день с трансфером, гидом и популярными остановками по маршруту.",
  },
  Гастрономия: {
    durationLabel: "2 ч. – 3 ч. 30 мин.",
    hours: 2.8,
    blurb:
      "Подборка вкусов и локальных мест, чтобы узнать город через его кухню.",
  },
  Шопинг: {
    durationLabel: "2 ч. – 4 ч.",
    hours: 3,
    blurb:
      "Маршрут по атмосферным кварталам, рынкам и популярным торговым точкам.",
  },
};

const CITY_DEFINITIONS = [
  {
    slug: "paris",
    city: "Париж",
    country: "Франция",
    heroTitle: "Варианты досуга в городе Париж",
    heroSubtitle:
      "Круизы по Сене, музеи, башни и самые популярные билеты в городе.",
    discoveryText: "Лучшие прогулки, музеи и речные круизы в столице Франции.",
    basePrice: 15300,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/paris-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Круиз по Сене от Эйфелевой башни", "Круизы"],
      ["Музей Орсе — входной билет", "Музеи"],
      ["Обзорная экскурсия по Парижу на автобусе", "История"],
      ["Эйфелева башня — приоритетный вход", "Смотровые площадки"],
      ["Лувр — вечерний билет", "Музеи"],
      ["Монмартр с местным гидом", "История"],
      ["Диснейленд Париж — билет на день", "Семейные"],
      ["Версаль с трансфером из центра", "Однодневные поездки"],
      ["Гастрономический тур по Маре", "Гастрономия"],
      ["Нотр-Дам и остров Сите", "История"],
      ["Круиз с ужином по Сене", "Круизы"],
      ["Смотровая площадка Монпарнас", "Смотровые площадки"],
      ["Латинский квартал и Пантеон", "История"],
      ["Парижские пассажи и бутики", "Шопинг"],
      ["Музей Оранжери — быстрый вход", "Музеи"],
      ["Парк Астерикс — билет", "Семейные"],
    ],
  },
  {
    slug: "rome",
    city: "Рим",
    country: "Италия",
    heroTitle: "Варианты досуга в городе Рим",
    heroSubtitle:
      "Древние руины, музеи Ватикана и прогулки по классическому Риму.",
    discoveryText: "Колизей, Ватикан и атмосферные прогулки по вечному городу.",
    basePrice: 18400,
    gallery: Array.from(
      { length: 4 },
      (_, index) => `https://picsum.photos/seed/rome-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Колизей, Форум и Палатин", "История"],
      ["Музеи Ватикана и Сикстинская капелла", "Музеи"],
      ["Подземелья Колизея", "История"],
      ["Рим на закате с гидом", "История"],
      ["Замок Святого Ангела", "История"],
      ["Фонтан Треви и Испанская лестница", "История"],
      ["Ватиканские сады", "Музеи"],
      ["Кулинарный тур по Трастевере", "Гастрономия"],
      ["Тиволи и вилла д'Эсте", "Однодневные поездки"],
      ["Купол собора Святого Петра", "Смотровые площадки"],
      ["Римский зоопарк Bioparco", "Семейные"],
      ["Галерея Боргезе", "Музеи"],
      ["Пантеон и площади барокко", "История"],
      ["Аутлет Castel Romano", "Шопинг"],
      ["Ночная прогулка по античному Риму", "История"],
      ["Кулинарный мастер-класс по пасте", "Гастрономия"],
    ],
  },
  {
    slug: "london",
    city: "Лондон",
    country: "Великобритания",
    heroTitle: "Варианты досуга в городе Лондон",
    heroSubtitle:
      "Шоу, музеи, речные круизы и билеты на главные обзорные площадки.",
    discoveryText:
      "Королевские достопримечательности, музеи и яркие city-experiences.",
    basePrice: 22600,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/london-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Лондонский Тауэр и королевские регалии", "История"],
      ["Круиз по Темзе", "Круизы"],
      ["Лондонский глаз — билет Fast Track", "Смотровые площадки"],
      ["Букингемский дворец летом", "История"],
      ["Гарри Поттер Studio Tour", "Семейные"],
      ["Вестминстер и Биг-Бен с гидом", "История"],
      ["Британский музей — экскурсия", "Музеи"],
      ["Тауэрский мост — стеклянный переход", "Смотровые площадки"],
      ["Камден и рынки северного Лондона", "Шопинг"],
      ["Национальная галерея", "Музеи"],
      ["Стоунхендж на один день", "Однодневные поездки"],
      ["Гастротур по Borough Market", "Гастрономия"],
      ["Собор Святого Павла", "История"],
      ["SEA LIFE London Aquarium", "Семейные"],
      ["The Shard — обзорная площадка", "Смотровые площадки"],
      ["Ночной автобусный тур по Лондону", "История"],
    ],
  },
  {
    slug: "dubai",
    city: "Дубай",
    country: "ОАЭ",
    heroTitle: "Варианты досуга в городе Дубай",
    heroSubtitle: "Башни, сафари, аквапарки и современный город у побережья.",
    discoveryText: "Бурдж-Халифа, пустынные туры и развлечения для всей семьи.",
    basePrice: 32700,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/dubai-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Бурдж-Халифа At the Top", "Смотровые площадки"],
      ["Пустынное сафари с ужином", "Однодневные поездки"],
      ["Дубай Молл и аквариум", "Семейные"],
      ["Круиз по Dubai Marina", "Круизы"],
      ["Музей будущего", "Музеи"],
      ["Старый Дубай и рынок специй", "История"],
      ["Atlantis Aquaventure", "Семейные"],
      ["Смотровая The View at The Palm", "Смотровые площадки"],
      ["Гастрономический тур по JBR", "Гастрономия"],
      ["Global Village", "Семейные"],
      ["Sky Views Observatory", "Смотровые площадки"],
      ["Шопинг в Mall of the Emirates", "Шопинг"],
      ["Абу-Даби на один день", "Однодневные поездки"],
      ["Лодочная прогулка у Palm Jumeirah", "Круизы"],
      ["Дубайская рамка", "Смотровые площадки"],
      ["Старинный квартал Аль-Фахиди", "История"],
    ],
  },
  {
    slug: "istanbul",
    city: "Стамбул",
    country: "Турция",
    heroTitle: "Варианты досуга в городе Стамбул",
    heroSubtitle: "Мечети, дворцы, базары и круизы между двумя континентами.",
    discoveryText: "Исторические кварталы, Босфор и восточная гастрономия.",
    basePrice: 13800,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/istanbul-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Айя-София и Голубая мечеть", "История"],
      ["Круиз по Босфору", "Круизы"],
      ["Дворец Топкапы", "История"],
      ["Цистерна Базилика", "История"],
      ["Галатская башня", "Смотровые площадки"],
      ["Гранд-базар с гидом", "Шопинг"],
      ["Вкусный Стамбул: street food тур", "Гастрономия"],
      ["Дворец Долмабахче", "История"],
      ["Принцевы острова на день", "Однодневные поездки"],
      ["Музей турецкого и исламского искусства", "Музеи"],
      ["Семейный день в Miniatürk", "Семейные"],
      ["Султанахмет на рассвете", "История"],
      ["Крытый рынок специй", "Шопинг"],
      ["Вечерний круиз с шоу", "Круизы"],
      ["Обзорные террасы в Бейоглу", "Смотровые площадки"],
      ["Керамика и ремесла Кадыкёя", "Шопинг"],
    ],
  },
  {
    slug: "tokyo",
    city: "Токио",
    country: "Япония",
    heroTitle: "Варианты досуга в городе Токио",
    heroSubtitle:
      "Храмы, смотровые, тематические парки и гастрономические кварталы.",
    discoveryText:
      "Современный мегаполис с яркими районами и культурными must-see.",
    basePrice: 24100,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/tokyo-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Tokyo Skytree — билет", "Смотровые площадки"],
      ["Храм Сэнсо-дзи и Асакуса", "История"],
      ["Командный тур по Сибуе", "История"],
      ["КомандныйLab Planets", "Музеи"],
      ["Токийский Диснейленд", "Семейные"],
      ["Рыбный рынок Тоёсу", "Гастрономия"],
      ["Императорский дворец и сады", "История"],
      ["Одайба на закате", "Смотровые площадки"],
      ["Харадзюку и модные улицы", "Шопинг"],
      ["Музей Гибли", "Музеи"],
      ["Фудзи на один день", "Однодневные поездки"],
      ["Суши-маршрут по Гиндзе", "Гастрономия"],
      ["Синдзюку и смотровая Tokyo Metropolitan", "Смотровые площадки"],
      ["Уэно и музеи парка", "Музеи"],
      ["Йокогама из Токио", "Однодневные поездки"],
      ["Акихабара и pop-culture тур", "Семейные"],
    ],
  },
  {
    slug: "samarkand",
    city: "Самарканд",
    country: "Узбекистан",
    heroTitle: "Варианты досуга в городе Самарканд",
    heroSubtitle:
      "Площади, мавзолеи и легендарные памятники на Великом шелковом пути.",
    discoveryText: "Регистан, мавзолеи и яркая архитектура Самарканда.",
    basePrice: 42000,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/samarkand-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Площадь Регистан с гидом", "История"],
      ["Мавзолей Гур-Эмир", "История"],
      ["Шахи-Зинда", "История"],
      ["Обсерватория Улугбека", "Музеи"],
      ["Сиабский базар и чайхана", "Гастрономия"],
      ["Самарканд на закате", "Смотровые площадки"],
      ["Ремесленные мастерские", "Шопинг"],
      ["Однодневный тур в Шахрисабз", "Однодневные поездки"],
      ["Исторический центр на электрокаре", "Семейные"],
      ["Афросиаб и музей археологии", "Музеи"],
      ["Тур по медресе и мечетям", "История"],
      ["Национальный ужин с мастер-классом", "Гастрономия"],
      ["Панорамы древнего Самарканда", "Смотровые площадки"],
      ["Комплекс Биби-Ханым", "История"],
      ["Семейный тур по легендам Шелкового пути", "Семейные"],
      ["Керамика и шелк Самарканда", "Шопинг"],
    ],
  },
  {
    slug: "bukhara",
    city: "Бухара",
    country: "Узбекистан",
    heroTitle: "Варианты досуга в городе Бухара",
    heroSubtitle:
      "Крепости, старые медресе и атмосферные дворики древнего города.",
    discoveryText:
      "Арк, Ляби-Хауз и старинные кварталы с восточной атмосферой.",
    basePrice: 36000,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/bukhara-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Крепость Арк", "История"],
      ["Ляби-Хауз и старый город", "История"],
      ["Комплекс Пои-Калян", "История"],
      ["Торговые купола Бухары", "Шопинг"],
      ["Бухарская кухня и плов", "Гастрономия"],
      ["Зиндон и легенды города", "История"],
      ["Смотровые точки старой Бухары", "Смотровые площадки"],
      ["Ситораи Мохи-Хоса", "Музеи"],
      ["Гиждуван на один день", "Однодневные поездки"],
      ["Ремесленные кварталы и ковры", "Шопинг"],
      ["Бухара для семей с детьми", "Семейные"],
      ["Вечерний тур по минаретам", "История"],
      ["Фототур по глиняным улицам", "Смотровые площадки"],
      ["Музей истории Бухары", "Музеи"],
      ["Национальный дом и чаепитие", "Гастрономия"],
      ["Тур по тайным дворикам", "История"],
    ],
  },
  {
    slug: "tashkent",
    city: "Ташкент",
    country: "Узбекистан",
    heroTitle: "Варианты досуга в городе Ташкент",
    heroSubtitle:
      "Базары, музеи, современные кварталы и горные выезды недалеко от города.",
    discoveryText:
      "Сочетание советской архитектуры, гастрономии и новых пространств.",
    basePrice: 30000,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/tashkent-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Чорсу базар с гидом", "Гастрономия"],
      ["Старый Ташкент и Хаст-Имам", "История"],
      ["Телебашня Ташкента", "Смотровые площадки"],
      ["Музей прикладного искусства", "Музеи"],
      ["Magic City для всей семьи", "Семейные"],
      ["Метро Ташкента — фототур", "История"],
      ["Гастротур по центру", "Гастрономия"],
      ["Чимган и Чарвак на день", "Однодневные поездки"],
      ["Broadway и арт-пространства", "Шопинг"],
      ["Ночной Ташкент", "Смотровые площадки"],
      ["Музей истории Тимуридов", "Музеи"],
      ["Экопарк и семейный отдых", "Семейные"],
      ["Базарчики и ремесленные лавки", "Шопинг"],
      ["Самые красивые мечети города", "История"],
      ["Канатная дорога Амирсой", "Однодневные поездки"],
      ["Узбекская кухня и сомса-тур", "Гастрономия"],
    ],
  },
  {
    slug: "agra",
    city: "Агра",
    country: "Индия",
    heroTitle: "Варианты досуга в городе Агра",
    heroSubtitle: "Тадж-Махал, крепости и насыщенные исторические маршруты.",
    discoveryText:
      "Знаковые памятники Могольской эпохи и одни из лучших видов в Индии.",
    basePrice: 19400,
    gallery: Array.from(
      { length: 4 },
      (_, index) => `https://picsum.photos/seed/agra-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Тадж-Махал на рассвете", "История"],
      ["Форт Агры", "История"],
      ["Мехтаб-Баг и лучшие виды", "Смотровые площадки"],
      ["Фатехпур-Сикри на день", "Однодневные поездки"],
      ["Агра: street food тур", "Гастрономия"],
      ["Мавзолей Итимад-уд-Даула", "История"],
      ["Тадж-Махал без очереди", "История"],
      ["Мастерские мраморной инкрустации", "Шопинг"],
      ["Семейный маршрут по историческому центру", "Семейные"],
      ["Ночная Агра и рынки", "Шопинг"],
      ["Акбаров мавзолей", "История"],
      ["Кулинарный мастер-класс в Агре", "Гастрономия"],
      ["Террасы с видом на Тадж", "Смотровые площадки"],
      ["Музей культуры Моголов", "Музеи"],
      ["Однодневная поездка в Матхуру", "Однодневные поездки"],
      ["Таджганж пешком", "История"],
    ],
  },
  {
    slug: "khiva",
    city: "Хива",
    country: "Узбекистан",
    heroTitle: "Варианты досуга в городе Хива",
    heroSubtitle: "Башни, старые стены и прогулки по музею под открытым небом.",
    discoveryText: "Ичан-Кала, древние стены и атмосферные улицы Хорезма.",
    basePrice: 28000,
    gallery: Array.from(
      { length: 4 },
      (_, index) =>
        `https://picsum.photos/seed/khiva-city-${index + 1}/420/280`,
    ),
    attractions: [
      ["Ичан-Кала и главные ворота", "История"],
      ["Куна-Арк", "История"],
      ["Минарет Ислам-Ходжи", "Смотровые площадки"],
      ["Дворец Таш-Ховли", "История"],
      ["Музеи внутри старого города", "Музеи"],
      ["Фольклорный вечер в Хиве", "Семейные"],
      ["Мастерские по дереву и керамике", "Шопинг"],
      ["Хорезмская кухня", "Гастрономия"],
      ["Тур на закате по стенам Хивы", "Смотровые площадки"],
      ["Прогулка по ремесленным кварталам", "История"],
      ["Топ-локации для фото", "Смотровые площадки"],
      ["Аяз-Кала на один день", "Однодневные поездки"],
      ["Семейная прогулка по старому городу", "Семейные"],
      ["Мечети и медресе Хивы", "История"],
      ["Национальный обед и чай", "Гастрономия"],
      ["Базар и сувениры Хивы", "Шопинг"],
    ],
  },
];

export const ATTRACTION_DISCOVERY_CARDS = [
  {
    id: "historic",
    title: "Исторические хиты",
    subtitle: "Главные памятники и древние кварталы в популярных городах",
    category: "История",
    image: "https://picsum.photos/seed/attractions-history/900/560",
    citySlug: "all",
  },
  {
    id: "museums",
    title: "Музеи и искусство",
    subtitle: "Коллекции, архитектура и билеты с быстрым входом",
    category: "Музеи",
    image: "https://picsum.photos/seed/attractions-museums/900/560",
    citySlug: "all",
  },
  {
    id: "cruises",
    title: "Круизы и прогулки",
    subtitle: "Водные маршруты, панорамы и вечерние огни городов",
    category: "Круизы",
    image: "https://picsum.photos/seed/attractions-cruises/900/560",
    citySlug: "all",
  },
  {
    id: "daytrips",
    title: "Поездки на весь день",
    subtitle: "Популярные выезды за пределы города с трансфером",
    category: "Однодневные поездки",
    image: "https://picsum.photos/seed/attractions-daytrips/900/560",
    citySlug: "all",
  },
];

function formatReviewLabel(rating) {
  if (rating >= 4.7) return "Потрясающе";
  if (rating >= 4.5) return "Превосходно";
  if (rating >= 4.2) return "Очень хорошо";
  return "Хорошо";
}

function buildDescription(city, name, category, index) {
  const categoryMeta = CATEGORY_META[category] || CATEGORY_META["История"];
  const intro = `${name} — один из самых популярных вариантов досуга в городе ${city}.`;
  const detail = categoryMeta.blurb;
  const ending =
    index % 3 === 0
      ? "Подходит для первого знакомства с направлением и удобен для самостоятельных поездок."
      : index % 3 === 1
        ? "Маршрут особенно любят гости, которые хотят увидеть больше за короткое время."
        : "Подборка хорошо подходит для насыщенного дня и красивых фотографий.";

  return `${intro} ${detail} ${ending}`;
}

function buildAttraction(cityDefinition, entry, index) {
  const [name, category] = entry;
  const categoryMeta = CATEGORY_META[category] || CATEGORY_META["История"];
  const rating = Number((4.2 + (index % 6) * 0.12).toFixed(1));
  const reviewsCount = 820 + index * 173 + cityDefinition.city.length * 11;
  const price = cityDefinition.basePrice + index * 2100;
  const originalPrice = Math.round(price * 1.12);
  const slug = `${cityDefinition.slug}-${index + 1}`;

  return {
    id: `${cityDefinition.slug}-${index + 1}`,
    city_slug: cityDefinition.slug,
    city: cityDefinition.city,
    country: cityDefinition.country,
    name,
    category,
    short_description: buildDescription(
      cityDefinition.city,
      name,
      category,
      index,
    ),
    rating,
    rating_label: formatReviewLabel(rating),
    reviews_count: reviewsCount,
    price,
    original_price: originalPrice,
    duration_hours: categoryMeta.hours,
    duration_label: categoryMeta.durationLabel,
    image_url: `https://picsum.photos/seed/${slug}-main/440/440`,
    gallery_images: Array.from(
      { length: 4 },
      (_, galleryIndex) =>
        `https://picsum.photos/seed/${slug}-thumb-${galleryIndex + 1}/216/216`,
    ),
    free_cancel: index % 5 !== 4,
    available_today: index % 4 !== 3,
    bestseller_rank: index < 5 ? index + 1 : null,
    is_genius: index % 4 === 1,
  };
}

export const ATTRACTION_CITIES = CITY_DEFINITIONS.map((cityDefinition) => {
  const attractions = cityDefinition.attractions.map((entry, index) =>
    buildAttraction(cityDefinition, entry, index),
  );

  return {
    ...cityDefinition,
    heroImage: cityDefinition.gallery[0],
    cardsCount: attractions.length,
    attractions,
  };
});

export const ATTRACTION_ALL_ITEMS = ATTRACTION_CITIES.flatMap(
  (city) => city.attractions,
);

export function slugifyAttractionCity(value = "") {
  return value
    .toString()
    .trim()
    .toLowerCase()
    .replace(/ё/g, "e")
    .replace(/[^a-zа-я0-9]+/gi, "-")
    .replace(/^-+|-+$/g, "");
}

export function getAttractionCityBySlug(slug) {
  if (!slug || slug === "all") {
    return {
      slug: "all",
      city: "Все города",
      country: "",
      heroTitle: "Все варианты досуга",
      heroSubtitle:
        "Подборка популярных экскурсий, музеев, прогулок и билетов в разных городах.",
      discoveryText: "Популярные развлечения в разных городах",
      gallery: ATTRACTION_CITIES.slice(0, 4).map((city) => city.gallery[0]),
      cardsCount: ATTRACTION_ALL_ITEMS.length,
      attractions: ATTRACTION_ALL_ITEMS,
    };
  }

  return (
    ATTRACTION_CITIES.find((city) => city.slug === slug) ||
    ATTRACTION_CITIES.find((city) => slugifyAttractionCity(city.city) === slug)
  );
}

export function getAttractionCityByName(cityName) {
  if (!cityName) return null;
  return (
    ATTRACTION_CITIES.find(
      (city) =>
        city.city.toLowerCase() === cityName.toString().trim().toLowerCase(),
    ) || null
  );
}

export function getAttractionCities() {
  return ATTRACTION_CITIES.map((city) => ({
    slug: city.slug,
    name: city.city,
    city: city.city,
    country: city.country,
    image_url: city.heroImage,
    gallery_images: city.gallery,
    variants: city.cardsCount,
    heroTitle: city.heroTitle,
    heroSubtitle: city.heroSubtitle,
    discoveryText: city.discoveryText,
  }));
}

export function getFallbackAttractions({ city, category, limit } = {}) {
  const cityData = city
    ? getAttractionCityByName(city) || getAttractionCityBySlug(city)
    : null;
  let items = cityData?.attractions || ATTRACTION_ALL_ITEMS;

  if (category) {
    items = items.filter((item) => item.category === category);
  }

  if (limit) {
    items = items.slice(0, limit);
  }

  return items;
}

export function getDiscoveryCards() {
  return ATTRACTION_DISCOVERY_CARDS.map((card, index) => ({
    ...card,
    totalItems: getFallbackAttractions({ category: card.category }).length,
    image:
      card.image || `https://picsum.photos/seed/discovery-${index + 1}/900/560`,
  }));
}
