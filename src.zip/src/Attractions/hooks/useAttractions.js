import { useQuery } from "react-query";
import {
  getAttractions,
  searchAttractions,
  getAttractionCities,
  getAttractionDiscoveryCards,
  getAttractionById,
  getAttractionBySlug,
} from "../api/attractions.js";

export function useAttractions(city, limit = 12) {
  return useQuery(
    ["attractions", city, limit],
    () => getAttractions({ city, limit }),
    { staleTime: 10 * 60 * 1000, retry: 1 },
  );
}

export function useSearchAttractions(params) {
  return useQuery(
    ["attractions", "search", params],
    () => searchAttractions(params),
    {
      enabled: !!(params?.query || params?.city || params?.category),
      staleTime: 2 * 60 * 1000,
      retry: 1,
    },
  );
}

export function useAttractionCities() {
  return useQuery(["attractions", "cities"], getAttractionCities, {
    staleTime: 10 * 60 * 1000,
    retry: 1,
  });
}

export function useAttractionDiscoveryCards() {
  return useQuery(["attractions", "discovery"], getAttractionDiscoveryCards, {
    staleTime: 10 * 60 * 1000,
    retry: 1,
  });
}

export function useAttractionById(id) {
  return useQuery(["attraction", "id", id], () => getAttractionById(id), {
    enabled: !!id,
    staleTime: 10 * 60 * 1000,
    retry: 1,
  });
}

export function useAttractionBySlug(slug) {
  return useQuery(
    ["attraction", "slug", slug],
    () => getAttractionBySlug(slug),
    { enabled: !!slug, staleTime: 10 * 60 * 1000, retry: 1 },
  );
}
