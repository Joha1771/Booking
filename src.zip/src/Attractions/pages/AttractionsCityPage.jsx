import { useMemo, useState } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Calendar,
  Clock3,
  Heart,
  MapPin,
  Search,
  Star,
  Ticket,
} from "lucide-react";
import Header from "../../components/layout/Header.jsx";
import Footer from "../../components/layout/Footer.jsx";
import {
  useAttractionCities,
  useAttractions,
  useSearchAttractions,
} from "../hooks/useAttractions.js";
import { getAttractionCityBySlug } from "../api/attractions.js";

function formatPrice(price) {
  if (!price || price <= 0) return "Бесплатно";
  return `UZS ${Math.round(price).toLocaleString("ru-RU")}`;
}

function buildAttractionsLink(slug, category, query) {
  const params = new URLSearchParams();
  if (category) params.set("category", category);
  if (query) params.set("query", query);
  const suffix = params.toString();
  return suffix ? `/attractions/${slug}?${suffix}` : `/attractions/${slug}`;
}

export default function AttractionsCityPage() {
  const navigate = useNavigate();
  const { citySlug = "all" } = useParams();
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchDraft, setSearchDraft] = useState(
    searchParams.get("query") || "",
  );
  const [date, setDate] = useState("");
  const [sortBy, setSortBy] = useState("recommended");
  const [priceLimit, setPriceLimit] = useState(250000);
  const [perks, setPerks] = useState({
    freeCancel: false,
    availableToday: false,
    genius: false,
  });
  const activeCategory = searchParams.get("category") || "";
  const activeQuery = searchParams.get("query") || "";

  const { data: cities = [] } = useAttractionCities();
  const { data: baseItems = [], isLoading: baseLoading } = useAttractions(
    citySlug === "all" ? null : citySlug,
    60,
  );
  const { data: filteredItems = [], isLoading: filteredLoading } =
    useSearchAttractions({
      city: citySlug === "all" ? undefined : citySlug,
      category: activeCategory || undefined,
      query: activeQuery || undefined,
      limit: 60,
    });

  const cityMeta =
    cities.find((city) => city.slug === citySlug) ||
    getAttractionCityBySlug(citySlug);
  const items = activeCategory || activeQuery ? filteredItems : baseItems;
  const isLoading =
    activeCategory || activeQuery ? filteredLoading : baseLoading;

  const categoryCards = useMemo(() => {
    const uniqueCategories = [
      ...new Set(baseItems.map((item) => item.category)),
    ].slice(0, 6);
    return uniqueCategories.map((category, index) => ({
      category,
      count: baseItems.filter((item) => item.category === category).length,
      image:
        baseItems.find((item) => item.category === category)?.image_url ||
        `https://picsum.photos/seed/${citySlug}-${index + 1}-category/900/620`,
    }));
  }, [baseItems, citySlug]);

  const maxItemPrice = useMemo(() => {
    const prices = items.map((item) => Number(item.price || 0)).filter(Boolean);
    return prices.length ? Math.max(...prices) : 250000;
  }, [items]);

  const visibleItems = useMemo(() => {
    let nextItems = items.filter(
      (item) => Number(item.price || 0) <= priceLimit,
    );

    if (perks.freeCancel) {
      nextItems = nextItems.filter((item) => item.free_cancel);
    }
    if (perks.availableToday) {
      nextItems = nextItems.filter((item) => item.available_today);
    }
    if (perks.genius) {
      nextItems = nextItems.filter((item) => item.is_genius);
    }

    if (sortBy === "price") {
      return [...nextItems].sort((left, right) => left.price - right.price);
    }
    if (sortBy === "rating") {
      return [...nextItems].sort((left, right) => right.rating - left.rating);
    }
    if (sortBy === "popular") {
      return [...nextItems].sort(
        (left, right) =>
          Number(left.bestseller_rank || 999) -
          Number(right.bestseller_rank || 999),
      );
    }

    return [...nextItems].sort((left, right) => {
      if (Boolean(right.is_genius) !== Boolean(left.is_genius)) {
        return (
          Number(Boolean(right.is_genius)) - Number(Boolean(left.is_genius))
        );
      }
      if (Boolean(right.free_cancel) !== Boolean(left.free_cancel)) {
        return (
          Number(Boolean(right.free_cancel)) - Number(Boolean(left.free_cancel))
        );
      }
      return right.rating - left.rating;
    });
  }, [items, perks, priceLimit, sortBy]);

  const handleSearchSubmit = () => {
    const trimmedQuery = searchDraft.trim();
    const nextParams = new URLSearchParams(searchParams);

    if (trimmedQuery) nextParams.set("query", trimmedQuery);
    else nextParams.delete("query");

    setSearchParams(nextParams);
  };

  const clearAllFilters = () => {
    setSearchDraft("");
    setSearchParams({});
    setPriceLimit(maxItemPrice);
    setPerks({ freeCancel: false, availableToday: false, genius: false });
    setSortBy("recommended");
  };

  const changeCategory = (category) => {
    navigate(
      buildAttractionsLink(
        citySlug,
        category === "Все" ? "" : category,
        activeQuery,
      ),
    );
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#f5f7fb",
        fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
      }}
    >
      <Header />

      <section style={{ background: "#003b95", padding: "24px 0 38px" }}>
        <div style={{ maxWidth: 1240, margin: "0 auto", padding: "0 16px" }}>
          <button
            type="button"
            onClick={() => navigate("/attractions")}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              border: "none",
              background: "transparent",
              color: "#fff",
              cursor: "pointer",
              fontSize: 14,
              fontWeight: 700,
              padding: 0,
              marginBottom: 18,
            }}
          >
            <ArrowLeft size={16} /> Назад к городам
          </button>

          <div style={{ maxWidth: 860 }}>
            <h1
              style={{
                color: "#fff",
                fontSize: "clamp(32px, 5vw, 48px)",
                lineHeight: 1.1,
                fontWeight: 900,
                margin: 0,
              }}
            >
              {cityMeta?.heroTitle || "Варианты досуга"}
            </h1>
            <p
              style={{
                color: "rgba(255,255,255,0.9)",
                fontSize: 16,
                lineHeight: 1.5,
                margin: "10px 0 26px",
              }}
            >
              {cityMeta?.heroSubtitle ||
                "Популярные развлечения, билеты и экскурсии."}
            </p>
          </div>

          <div
            style={{
              background: "#febb02",
              borderRadius: 18,
              padding: 6,
              boxShadow: "0 18px 36px rgba(15, 23, 42, 0.16)",
            }}
          >
            <div
              style={{
                display: "grid",
                gridTemplateColumns:
                  "minmax(0, 1.55fr) minmax(220px, 0.72fr) 148px",
                gap: 6,
              }}
            >
              <div
                style={{
                  minHeight: 64,
                  background: "#fff",
                  borderRadius: 14,
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "0 16px",
                }}
              >
                <Search size={18} color="#6b7280" />
                <div style={{ flex: 1 }}>
                  <div
                    style={{ fontSize: 11, color: "#6b7280", marginBottom: 2 }}
                  >
                    Найти развлечение
                  </div>
                  <input
                    value={searchDraft}
                    onChange={(event) => setSearchDraft(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        event.preventDefault();
                        handleSearchSubmit();
                      }
                    }}
                    placeholder="Круиз, музей, билет..."
                    style={{
                      width: "100%",
                      border: "none",
                      outline: "none",
                      background: "transparent",
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#111827",
                    }}
                  />
                </div>
              </div>

              <div
                style={{
                  minHeight: 64,
                  background: "#fff",
                  borderRadius: 14,
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "0 16px",
                }}
              >
                <Calendar size={18} color="#6b7280" />
                <div style={{ flex: 1 }}>
                  <div
                    style={{ fontSize: 11, color: "#6b7280", marginBottom: 2 }}
                  >
                    Даты
                  </div>
                  <input
                    type="date"
                    value={date}
                    onChange={(event) => setDate(event.target.value)}
                    style={{
                      width: "100%",
                      border: "none",
                      outline: "none",
                      background: "transparent",
                      fontSize: 16,
                      fontWeight: 700,
                      color: "#111827",
                    }}
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={handleSearchSubmit}
                style={{
                  minHeight: 64,
                  border: "none",
                  borderRadius: 14,
                  background: "#0071c2",
                  color: "#fff",
                  fontSize: 17,
                  fontWeight: 800,
                  cursor: "pointer",
                }}
              >
                Поиск
              </button>
            </div>
          </div>
        </div>
      </section>

      <section style={{ padding: "28px 0 40px" }}>
        <div style={{ maxWidth: 1240, margin: "0 auto", padding: "0 16px" }}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "290px minmax(0, 1fr)",
              gap: 20,
              alignItems: "start",
            }}
          >
            <aside
              style={{
                position: "sticky",
                top: 88,
                display: "flex",
                flexDirection: "column",
                gap: 14,
              }}
            >
              <div
                style={{
                  border: "1px solid #e5e7eb",
                  borderRadius: 18,
                  background: "#fff",
                  padding: 18,
                }}
              >
                <div
                  style={{
                    fontSize: 17,
                    fontWeight: 900,
                    color: "#111827",
                    marginBottom: 14,
                  }}
                >
                  Фильтры
                </div>
                <div
                  style={{ fontSize: 13, fontWeight: 800, marginBottom: 10 }}
                >
                  Категории
                </div>
                <div style={{ display: "grid", gap: 8, marginBottom: 18 }}>
                  {["Все", ...categoryCards.map((card) => card.category)].map(
                    (category) => {
                      const active =
                        (!activeCategory && category === "Все") ||
                        activeCategory === category;
                      return (
                        <button
                          key={category}
                          type="button"
                          onClick={() => changeCategory(category)}
                          style={{
                            border: active
                              ? "1px solid #003b95"
                              : "1px solid #d1d5db",
                            background: active ? "#e7f0ff" : "#fff",
                            borderRadius: 12,
                            padding: "10px 12px",
                            fontSize: 13,
                            fontWeight: 700,
                            cursor: "pointer",
                            textAlign: "left",
                          }}
                        >
                          {category}
                        </button>
                      );
                    },
                  )}
                </div>

                <div
                  style={{ fontSize: 13, fontWeight: 800, marginBottom: 10 }}
                >
                  Максимальная цена
                </div>
                <div
                  style={{ fontSize: 13, color: "#6b7280", marginBottom: 8 }}
                >
                  До {formatPrice(priceLimit)}
                </div>
                <input
                  type="range"
                  min={0}
                  max={Math.max(maxItemPrice, 250000)}
                  value={Math.min(priceLimit, Math.max(maxItemPrice, 250000))}
                  onChange={(event) =>
                    setPriceLimit(Number(event.target.value))
                  }
                  style={{ width: "100%", marginBottom: 18 }}
                />

                <div
                  style={{ fontSize: 13, fontWeight: 800, marginBottom: 10 }}
                >
                  Особенности
                </div>
                <div style={{ display: "grid", gap: 10 }}>
                  {[
                    { key: "freeCancel", label: "Бесплатная отмена" },
                    { key: "availableToday", label: "Доступно сегодня" },
                    { key: "genius", label: "Genius" },
                  ].map((perk) => (
                    <label
                      key={perk.key}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        fontSize: 13,
                        cursor: "pointer",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={perks[perk.key]}
                        onChange={(event) =>
                          setPerks((current) => ({
                            ...current,
                            [perk.key]: event.target.checked,
                          }))
                        }
                      />
                      {perk.label}
                    </label>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={clearAllFilters}
                  style={{
                    marginTop: 18,
                    width: "100%",
                    border: "1px solid #cbd5e1",
                    background: "#fff",
                    borderRadius: 12,
                    padding: "10px 14px",
                    cursor: "pointer",
                    fontWeight: 700,
                    fontSize: 13,
                  }}
                >
                  Сбросить фильтры
                </button>
              </div>
            </aside>

            <div>
              <div
                style={{
                  border: "1px solid #e5e7eb",
                  borderRadius: 18,
                  background: "#fff",
                  padding: 18,
                  marginBottom: 16,
                }}
              >
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    gap: 12,
                    flexWrap: "wrap",
                  }}
                >
                  <div>
                    <div
                      style={{
                        fontSize: 28,
                        fontWeight: 900,
                        color: "#111827",
                      }}
                    >
                      {isLoading
                        ? "Загружаем развлечения..."
                        : `${visibleItems.length} вариантов`}
                    </div>
                    <div
                      style={{ fontSize: 14, color: "#6b7280", marginTop: 6 }}
                    >
                      {cityMeta?.city === "Все города"
                        ? "Подборка лучших карточек досуга из разных направлений."
                        : `Развлечения, билеты и экскурсии в городе ${cityMeta?.city}.`}
                    </div>
                  </div>

                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {[
                      { key: "recommended", label: "Наш выбор" },
                      { key: "price", label: "Цена" },
                      { key: "rating", label: "Оценка" },
                      { key: "popular", label: "Популярные" },
                    ].map((option) => {
                      const active = sortBy === option.key;
                      return (
                        <button
                          key={option.key}
                          type="button"
                          onClick={() => setSortBy(option.key)}
                          style={{
                            border: active
                              ? "1px solid #003b95"
                              : "1px solid #d1d5db",
                            background: active ? "#e7f0ff" : "#fff",
                            borderRadius: 999,
                            padding: "10px 14px",
                            fontSize: 13,
                            fontWeight: 700,
                            cursor: "pointer",
                          }}
                        >
                          {option.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {categoryCards.length > 0 && (
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                    gap: 14,
                    marginBottom: 18,
                  }}
                >
                  {categoryCards.slice(0, 4).map((card) => {
                    const active = activeCategory === card.category;
                    return (
                      <button
                        key={card.category}
                        type="button"
                        onClick={() =>
                          navigate(
                            buildAttractionsLink(
                              citySlug,
                              active ? "" : card.category,
                              activeQuery,
                            ),
                          )
                        }
                        style={{
                          border: active
                            ? "2px solid #0071c2"
                            : "1px solid #e5e7eb",
                          borderRadius: 18,
                          background: "#fff",
                          padding: 0,
                          overflow: "hidden",
                          textAlign: "left",
                          cursor: "pointer",
                        }}
                      >
                        <img
                          src={card.image}
                          alt={card.category}
                          style={{
                            width: "100%",
                            height: 136,
                            objectFit: "cover",
                            display: "block",
                          }}
                        />
                        <div style={{ padding: 14 }}>
                          <div
                            style={{
                              fontSize: 17,
                              fontWeight: 800,
                              color: "#111827",
                            }}
                          >
                            {card.category}
                          </div>
                          <div
                            style={{
                              fontSize: 13,
                              color: "#6b7280",
                              marginTop: 6,
                            }}
                          >
                            {card.count} карточек в подборке
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              <div style={{ display: "grid", gap: 16 }}>
                {isLoading
                  ? Array.from({ length: 6 }).map((_, index) => (
                      <div
                        key={index}
                        style={{
                          minHeight: 308,
                          borderRadius: 22,
                          background: "#f3f4f6",
                        }}
                      />
                    ))
                  : visibleItems.map((item) => (
                      <article
                        key={item.id}
                        style={{
                          border: "1px solid #e5e7eb",
                          borderRadius: 22,
                          background: "#fff",
                          overflow: "hidden",
                          boxShadow: "0 10px 22px rgba(15, 23, 42, 0.05)",
                        }}
                      >
                        <div
                          style={{
                            display: "grid",
                            gridTemplateColumns: "240px minmax(0, 1fr) 220px",
                            gap: 18,
                            padding: 18,
                            alignItems: "stretch",
                          }}
                        >
                          <div style={{ minWidth: 0 }}>
                            <img
                              src={item.image_url}
                              alt={item.name}
                              style={{
                                width: "100%",
                                height: 182,
                                borderRadius: 16,
                                objectFit: "cover",
                                display: "block",
                                marginBottom: 10,
                              }}
                            />
                            <div
                              style={{
                                display: "grid",
                                gridTemplateColumns: "repeat(4, 1fr)",
                                gap: 8,
                              }}
                            >
                              {item.gallery_images
                                .slice(0, 4)
                                .map((image, index) => (
                                  <img
                                    key={`${item.id}-${index}`}
                                    src={image}
                                    alt=""
                                    style={{
                                      width: "100%",
                                      height: 56,
                                      borderRadius: 10,
                                      objectFit: "cover",
                                      display: "block",
                                    }}
                                  />
                                ))}
                            </div>
                          </div>

                          <div style={{ minWidth: 0 }}>
                            <div
                              style={{
                                display: "flex",
                                gap: 8,
                                flexWrap: "wrap",
                                marginBottom: 10,
                              }}
                            >
                              {item.bestseller_rank ? (
                                <span
                                  style={{
                                    borderRadius: 999,
                                    background: "#fff4d5",
                                    color: "#8a5a00",
                                    fontSize: 12,
                                    fontWeight: 800,
                                    padding: "6px 10px",
                                  }}
                                >
                                  № {item.bestseller_rank} по популярности
                                </span>
                              ) : null}
                              {item.is_genius ? (
                                <span
                                  style={{
                                    borderRadius: 999,
                                    background: "#003b95",
                                    color: "#fff",
                                    fontSize: 12,
                                    fontWeight: 800,
                                    padding: "6px 10px",
                                  }}
                                >
                                  Genius
                                </span>
                              ) : null}
                            </div>

                            <div
                              style={{
                                display: "flex",
                                justifyContent: "space-between",
                                gap: 12,
                                alignItems: "flex-start",
                              }}
                            >
                              <div style={{ minWidth: 0 }}>
                                <h2
                                  style={{
                                    margin: 0,
                                    fontSize: 28,
                                    lineHeight: 1.15,
                                    fontWeight: 900,
                                    color: "#111827",
                                  }}
                                >
                                  {item.name}
                                </h2>
                                <div
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 6,
                                    marginTop: 10,
                                    color: "#6b7280",
                                  }}
                                >
                                  <MapPin size={15} />
                                  <span style={{ fontSize: 14 }}>
                                    {item.city}, {item.country}
                                  </span>
                                </div>
                              </div>

                              <button
                                type="button"
                                style={{
                                  width: 40,
                                  height: 40,
                                  borderRadius: "50%",
                                  border: "1px solid #d1d5db",
                                  background: "#fff",
                                  display: "flex",
                                  alignItems: "center",
                                  justifyContent: "center",
                                  cursor: "pointer",
                                  flexShrink: 0,
                                }}
                              >
                                <Heart size={18} color="#4b5563" />
                              </button>
                            </div>

                            <p
                              style={{
                                fontSize: 15,
                                lineHeight: 1.6,
                                color: "#4b5563",
                                margin: "14px 0 16px",
                              }}
                            >
                              {item.short_description}
                            </p>

                            <div
                              style={{
                                display: "flex",
                                gap: 18,
                                flexWrap: "wrap",
                                marginBottom: 14,
                              }}
                            >
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 8,
                                  color: "#334155",
                                }}
                              >
                                <Clock3 size={16} />
                                <span style={{ fontSize: 14 }}>
                                  {item.duration_label}
                                </span>
                              </div>
                              <div
                                style={{
                                  display: "flex",
                                  alignItems: "center",
                                  gap: 8,
                                  color: "#334155",
                                }}
                              >
                                <Star
                                  size={16}
                                  fill="#febb02"
                                  color="#febb02"
                                />
                                <span style={{ fontSize: 14, fontWeight: 700 }}>
                                  {Number(item.rating).toFixed(1)}
                                </span>
                                <span style={{ fontSize: 14 }}>
                                  {item.rating_label} (
                                  {item.reviews_count.toLocaleString("ru-RU")})
                                </span>
                              </div>
                              {item.free_cancel ? (
                                <div
                                  style={{
                                    display: "flex",
                                    alignItems: "center",
                                    gap: 8,
                                    color: "#008234",
                                  }}
                                >
                                  <Ticket size={16} />
                                  <span style={{ fontSize: 14 }}>
                                    Доступна бесплатная отмена
                                  </span>
                                </div>
                              ) : null}
                            </div>
                          </div>

                          <div
                            style={{
                              display: "flex",
                              flexDirection: "column",
                              alignItems: "flex-end",
                              justifyContent: "space-between",
                              gap: 18,
                            }}
                          >
                            <div style={{ textAlign: "right" }}>
                              {item.original_price > item.price ? (
                                <div
                                  style={{
                                    fontSize: 13,
                                    color: "#6b7280",
                                    marginBottom: 4,
                                  }}
                                >
                                  От <s>{formatPrice(item.original_price)}</s>
                                </div>
                              ) : null}
                              <div
                                style={{
                                  fontSize: 32,
                                  fontWeight: 900,
                                  color: "#111827",
                                }}
                              >
                                {formatPrice(item.price)}
                              </div>
                              <div
                                style={{
                                  fontSize: 13,
                                  color: "#6b7280",
                                  marginTop: 4,
                                }}
                              >
                                Включая налоги и сборы
                              </div>
                              {item.available_today ? (
                                <div
                                  style={{
                                    fontSize: 13,
                                    color: "#008234",
                                    fontWeight: 700,
                                    marginTop: 8,
                                  }}
                                >
                                  Доступно с сегодняшнего дня
                                </div>
                              ) : null}
                            </div>

                            <button
                              type="button"
                              onClick={() =>
                                navigate(`/attractions/detail/${item.id}`)
                              }
                              style={{
                                minWidth: 200,
                                border: "none",
                                borderRadius: 12,
                                background: "#0071c2",
                                color: "#fff",
                                padding: "14px 18px",
                                fontSize: 15,
                                fontWeight: 800,
                                cursor: "pointer",
                                display: "inline-flex",
                                alignItems: "center",
                                justifyContent: "center",
                                gap: 8,
                              }}
                            >
                              Посмотреть наличие мест <ArrowRight size={16} />
                            </button>
                          </div>
                        </div>
                      </article>
                    ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
