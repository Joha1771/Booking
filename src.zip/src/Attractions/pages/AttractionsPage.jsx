import { useState, useRef, useEffect, useMemo } from "react";
import Header from "../../components/layout/Header.jsx";
import Footer from "../../components/layout/Footer.jsx";
import {
  useTrendingDestinations,
  useAllDestinations,
} from "../../hooks/useQueries.js";
import { useAttractions } from "../hooks/useAttractions.js";
import { Search, Calendar, Star, Heart } from "lucide-react";
import GeniusSection from "../../components/sections/GeniusSection.jsx";

const ATTRACTION_DESTINATIONS = [
  "🇺🇿 Самарканд — площадь Регистан",
  "🇺🇿 Бухара — Арк и Ляби-Хауз",
  "🇺🇿 Хива — Ичан-Кала (Старый город)",
  "🇺🇿 Ташкент — Чорсу базар",
  "🇺🇿 Шахрисабз — Ак-Сарай",
  "🇹🇷 Стамбул — Айя-София",
  "🇦🇪 Дубай — Бурдж-Халифа",
  "🇮🇳 Агра — Тадж-Махал",
  "🇫🇷 Париж — Эйфелева башня",
  "🇮🇹 Рим — Колизей",
  "🇬🇧 Лондон — Тауэр",
  "🇯🇵 Токио — Храм Сенсо-дзи",
];

const normalizeValue = (value = "") => value.toString().trim().toLowerCase();

const getSuggestionCity = (label = "") =>
  label
    .replace(/^.+?\s/, "")
    .split("—")[0]
    .trim();

export default function AttractionsPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedDestination, setSelectedDestination] = useState(null);
  const searchRef = useRef(null);
  const attractionsSectionRef = useRef(null);
  const [date, setDate] = useState("");
  const carouselRef = useRef(null);

  const filteredDests =
    searchQuery.length > 0
      ? ATTRACTION_DESTINATIONS.filter((d) =>
          d.toLowerCase().includes(searchQuery.toLowerCase()),
        ).slice(0, 6)
      : ATTRACTION_DESTINATIONS.slice(0, 6);

  useEffect(() => {
    const handler = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target))
        setSearchOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const { data: attractions = [], isLoading: loadingAttr } = useAttractions(
    null,
    64,
  );
  const { data: trending = [] } = useTrendingDestinations();
  const { data: allDests = [] } = useAllDestinations(200);

  const fmt = (p) =>
    p > 0 ? "UZS " + Math.round(p).toLocaleString("ru-RU") : "Бесплатно";

  const attractionsWithBadge = attractions.map((a, i) => ({
    ...a,
    popBadge:
      i === 0
        ? "№ 1 по популярности"
        : i === 1
          ? "Genius -37%"
          : i === 2
            ? "№ 2 по популярности"
            : i === 3
              ? "Genius -10%"
              : null,
    popBadgeGenius: i === 1 || i === 3,
  }));

  const scrollToAttractions = () => {
    window.requestAnimationFrame(() => {
      attractionsSectionRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    });
  };

  const handleDestinationSelect = (destination) => {
    const nextDestination =
      typeof destination === "string"
        ? { name: destination.trim(), country: "" }
        : {
            name: destination?.name?.trim() || "",
            country: destination?.country?.trim() || "",
          };

    if (!nextDestination.name) return;

    setSelectedDestination(nextDestination);
    setSearchQuery(nextDestination.name);
    setSearchOpen(false);
    scrollToAttractions();
  };

  const selectedAttractionsState = useMemo(() => {
    if (!selectedDestination?.name) {
      return {
        title: "Популярные экскурсии для вас",
        subtitle:
          "Нажмите на направление ниже, и мы покажем подходящие карточки экскурсий.",
        items: attractionsWithBadge,
        fallbackMessage: "",
      };
    }

    const normalizedCity = normalizeValue(selectedDestination.name);
    const exactMatches = attractionsWithBadge.filter(
      (attraction) => normalizeValue(attraction.city) === normalizedCity,
    );

    if (exactMatches.length > 0) {
      return {
        title: `${selectedDestination.name}: наши рекомендации`,
        subtitle: `Наша подборка лучших вариантов досуга в городе ${selectedDestination.name}.`,
        items: exactMatches,
        fallbackMessage: "",
      };
    }

    const countryMatches = selectedDestination.country
      ? attractionsWithBadge.filter(
          (attraction) =>
            normalizeValue(attraction.country) ===
            normalizeValue(selectedDestination.country),
        )
      : [];

    if (countryMatches.length > 0) {
      return {
        title: `${selectedDestination.name}: наши рекомендации`,
        subtitle: `Прямых карточек для ${selectedDestination.name} пока нет, поэтому показываем популярные экскурсии по стране ${selectedDestination.country}.`,
        items: countryMatches,
        fallbackMessage: `Пока нет отдельных карточек для ${selectedDestination.name}.`,
      };
    }

    return {
      title: `${selectedDestination.name}: наши рекомендации`,
      subtitle: `Для ${selectedDestination.name} пока нет отдельных карточек, поэтому показываем самые популярные экскурсии.`,
      items: attractionsWithBadge.slice(0, 8),
      fallbackMessage: `Пока нет отдельных карточек для ${selectedDestination.name}.`,
    };
  }, [attractionsWithBadge, selectedDestination]);

  const isDestinationSelected = (name) =>
    normalizeValue(selectedDestination?.name) === normalizeValue(name);

  const handleSearchSubmit = () => {
    const trimmedQuery = searchQuery.trim();
    if (!trimmedQuery) {
      setSelectedDestination(null);
      scrollToAttractions();
      return;
    }

    const matchingDestination =
      allDests.find((destination) =>
        normalizeValue(destination.name).includes(normalizeValue(trimmedQuery)),
      ) ||
      trending.find((destination) =>
        normalizeValue(destination.name).includes(normalizeValue(trimmedQuery)),
      );

    handleDestinationSelect(
      matchingDestination || { name: trimmedQuery, country: "" },
    );
  };

  const scroll = (dir) => {
    if (carouselRef.current)
      carouselRef.current.scrollBy({ left: dir * 240, behavior: "smooth" });
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#fff",
        fontFamily: '-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
      }}
    >
      <Header />

      {/* Hero */}
      <div style={{ background: "#003580", paddingBottom: 40 }}>
        <div
          style={{ maxWidth: 1150, margin: "0 auto", padding: "40px 16px 0" }}
        >
          <h1
            style={{
              color: "#fff",
              fontSize: 40,
              fontWeight: 800,
              marginBottom: 8,
            }}
          >
            Экскурсии и развлечения
          </h1>
          <p
            style={{
              color: "rgba(255,255,255,0.9)",
              fontSize: 16,
              marginBottom: 28,
            }}
          >
            Найдите новые варианты досуга по вкусу и интересам.
          </p>
          <div className="page-hero-form">
            <div
              ref={searchRef}
              className="page-hero-field-grow"
              style={{
                background: "#fff",
                borderRadius: 2,
                padding: "10px 14px",
                display: "flex",
                alignItems: "center",
                gap: 10,
                minHeight: 48,
                position: "relative",
              }}
            >
              <Search size={18} color="#555" style={{ flexShrink: 0 }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 11, color: "#888" }}>Направление</div>
                <input
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setSearchOpen(true);
                  }}
                  onFocus={() => setSearchOpen(true)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      handleSearchSubmit();
                    }
                  }}
                  placeholder="Куда вы хотите поехать?"
                  style={{
                    border: "none",
                    outline: "none",
                    fontSize: 14,
                    width: "100%",
                    background: "transparent",
                  }}
                />
              </div>
              {searchOpen && filteredDests.length > 0 && (
                <div
                  style={{
                    position: "absolute",
                    top: "100%",
                    left: 0,
                    zIndex: 200,
                    background: "#fff",
                    borderRadius: 8,
                    boxShadow: "0 4px 24px rgba(0,0,0,0.18)",
                    width: "100%",
                    maxWidth: 420,
                    overflow: "hidden",
                    marginTop: 4,
                  }}
                >
                  {filteredDests.map((d, i) => (
                    <div
                      key={i}
                      onMouseDown={() => {
                        handleDestinationSelect(getSuggestionCity(d));
                      }}
                      style={{
                        padding: "10px 16px",
                        cursor: "pointer",
                        fontSize: 13,
                        borderBottom: "1px solid #f0f0f0",
                      }}
                      onMouseEnter={(e) =>
                        (e.currentTarget.style.background = "#f5f7ff")
                      }
                      onMouseLeave={(e) =>
                        (e.currentTarget.style.background = "#fff")
                      }
                    >
                      {d}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div
              className="page-hero-field-md"
              style={{
                background: "#fff",
                borderRadius: 2,
                padding: "10px 14px",
                display: "flex",
                alignItems: "center",
                gap: 10,
                minHeight: 48,
              }}
            >
              <Calendar size={16} color="#555" style={{ flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: 11, color: "#888" }}>Даты</div>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  placeholder="Выберите даты"
                  style={{
                    border: "none",
                    outline: "none",
                    fontSize: 14,
                    cursor: "pointer",
                    background: "transparent",
                  }}
                />
              </div>
            </div>
            <button
              onClick={handleSearchSubmit}
              className="page-hero-submit"
              style={{
                background: "#0071c2",
                color: "#fff",
                border: "none",
                borderRadius: 2,
                padding: "0 28px",
                fontSize: 16,
                fontWeight: 700,
                cursor: "pointer",
                whiteSpace: "nowrap",
              }}
            >
              Проверить цены
            </button>
          </div>
        </div>
      </div>

      {/* Recommendations carousel */}
      <div
        ref={attractionsSectionRef}
        style={{ maxWidth: 1150, margin: "0 auto", padding: "32px 16px 0" }}
      >
        <div className="page-inline-header" style={{ marginBottom: 8 }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>
              {selectedAttractionsState.title}
            </div>
            <div style={{ fontSize: 13, color: "#595959", marginTop: 2 }}>
              {selectedAttractionsState.subtitle}
            </div>
          </div>
          <a
            href="#"
            onClick={(event) => {
              event.preventDefault();
              setSelectedDestination(null);
              setSearchQuery("");
            }}
            style={{
              fontSize: 14,
              color: "#0071c2",
              textDecoration: "none",
              fontWeight: 500,
              whiteSpace: "nowrap",
            }}
          >
            Сбросить
          </a>
        </div>

        {selectedAttractionsState.fallbackMessage && (
          <div
            style={{
              marginBottom: 14,
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              padding: "8px 12px",
              borderRadius: 999,
              background: "#f0f6ff",
              color: "#0057b8",
              fontSize: 13,
              fontWeight: 600,
            }}
          >
            {selectedAttractionsState.fallbackMessage}
          </div>
        )}

        <div style={{ position: "relative" }}>
          <div
            ref={carouselRef}
            style={{
              display: "flex",
              gap: 12,
              overflowX: "auto",
              scrollSnapType: "x mandatory",
              scrollbarWidth: "none",
              paddingBottom: 8,
            }}
          >
            {loadingAttr
              ? Array.from({ length: 4 }).map((_, i) => (
                  <div
                    key={i}
                    style={{
                      minWidth: 220,
                      height: 300,
                      background: "#f0f0f0",
                      borderRadius: 8,
                      flexShrink: 0,
                      scrollSnapAlign: "start",
                    }}
                  />
                ))
              : selectedAttractionsState.items.map((a, i) => (
                  <div
                    key={a.id || i}
                    style={{
                      minWidth: 220,
                      flexShrink: 0,
                      scrollSnapAlign: "start",
                      borderRadius: 8,
                      overflow: "hidden",
                      border: "1px solid #e7e7e7",
                      cursor: "pointer",
                      background: "#fff",
                    }}
                  >
                    <div style={{ position: "relative" }}>
                      <img
                        src={
                          a.image_url ||
                          a.image ||
                          `https://picsum.photos/seed/attr${i}/400/260`
                        }
                        alt={a.name}
                        style={{
                          width: "100%",
                          height: 170,
                          objectFit: "cover",
                          display: "block",
                        }}
                        onError={(e) => {
                          e.target.src = `https://picsum.photos/seed/attr${i}/400/260`;
                        }}
                      />
                      {a.popBadge && (
                        <div
                          style={{
                            position: "absolute",
                            top: 10,
                            left: 10,
                            background: a.popBadgeGenius
                              ? "#003580"
                              : "#003580",
                            color: "#fff",
                            fontSize: 11,
                            fontWeight: 700,
                            padding: "3px 8px",
                            borderRadius: 2,
                          }}
                        >
                          {a.popBadge}
                        </div>
                      )}
                      <button
                        style={{
                          position: "absolute",
                          top: 8,
                          right: 8,
                          background: "rgba(255,255,255,0.9)",
                          border: "none",
                          borderRadius: "50%",
                          width: 30,
                          height: 30,
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <Heart size={15} color="#555" />
                      </button>
                    </div>
                    <div style={{ padding: "12px" }}>
                      <div
                        style={{
                          fontSize: 13,
                          fontWeight: 600,
                          marginBottom: 6,
                          lineHeight: 1.3,
                        }}
                      >
                        {a.name}
                      </div>
                      {a.rating > 0 && (
                        <div
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 6,
                            marginBottom: 4,
                          }}
                        >
                          <Star size={13} fill="#febb02" color="#febb02" />
                          <span style={{ fontSize: 13, fontWeight: 700 }}>
                            {Number(a.rating).toFixed(1)}
                          </span>
                          {a.reviews_count > 0 && (
                            <span style={{ fontSize: 12, color: "#888" }}>
                              ({a.reviews_count})
                            </span>
                          )}
                        </div>
                      )}
                      <div style={{ fontSize: 13, color: "#333" }}>
                        С {fmt(a.price)}
                      </div>
                    </div>
                  </div>
                ))}
          </div>
          <button
            onClick={() => scroll(-1)}
            style={{
              position: "absolute",
              left: -16,
              top: "40%",
              transform: "translateY(-50%)",
              width: 36,
              height: 36,
              borderRadius: "50%",
              background: "#fff",
              border: "1px solid #e7e7e7",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
              fontSize: 20,
              zIndex: 2,
            }}
          >
            ‹
          </button>
          <button
            onClick={() => scroll(1)}
            style={{
              position: "absolute",
              right: -16,
              top: "40%",
              transform: "translateY(-50%)",
              width: 36,
              height: 36,
              borderRadius: "50%",
              background: "#fff",
              border: "1px solid #e7e7e7",
              cursor: "pointer",
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
              fontSize: 20,
              zIndex: 2,
            }}
          >
            ›
          </button>
        </div>
      </div>

      {/* Nearby destinations */}
      {trending.length > 0 && (
        <div
          style={{ maxWidth: 1150, margin: "0 auto", padding: "40px 16px 0" }}
        >
          <div style={{ fontSize: 18, fontWeight: 700, marginBottom: 16 }}>
            Направления поблизости
          </div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
            {trending.slice(0, 6).map((d, i) => (
              <div
                onClick={() => handleDestinationSelect(d)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    handleDestinationSelect(d);
                  }
                }}
                role="button"
                tabIndex={0}
                key={d.id || i}
                style={{
                  flex: "1 1 180px",
                  width: "auto",
                  borderRadius: 8,
                  overflow: "hidden",
                  cursor: "pointer",
                  position: "relative",
                  outline: "none",
                  boxShadow: isDestinationSelected(d.name)
                    ? "0 0 0 3px rgba(0, 113, 194, 0.28)"
                    : "none",
                }}
              >
                <img
                  src={
                    d.image_url || `https://picsum.photos/seed/dest${i}/300/200`
                  }
                  alt={d.name}
                  style={{
                    width: "100%",
                    height: 150,
                    objectFit: "cover",
                    display: "block",
                  }}
                  onError={(e) => {
                    e.target.src = `https://picsum.photos/seed/dest${i}/300/200`;
                  }}
                />
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 0,
                    right: 0,
                    background: "linear-gradient(transparent, rgba(0,0,0,0.7))",
                    color: "#fff",
                    padding: "20px 12px 10px",
                  }}
                >
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{d.name}</div>
                  {d.variants > 0 && (
                    <div style={{ fontSize: 12, opacity: 0.85 }}>
                      {d.variants.toLocaleString("ru-RU")} варианта
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Genius section */}
      <GeniusSection />
      {/* All destinations grid */}
      {allDests.length > 0 && (
        <div
          style={{ maxWidth: 1150, margin: "0 auto", padding: "0 16px 48px" }}
        >
          <div className="attractions-grid" style={{ gap: 8 }}>
            {allDests.map((d, i) => (
              <div
                onClick={() => handleDestinationSelect(d)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    handleDestinationSelect(d);
                  }
                }}
                role="button"
                tabIndex={0}
                key={d.id || i}
                style={{
                  borderRadius: 8,
                  overflow: "hidden",
                  cursor: "pointer",
                  position: "relative",
                  outline: "none",
                  boxShadow: isDestinationSelected(d.name)
                    ? "0 0 0 3px rgba(0, 113, 194, 0.28)"
                    : "none",
                }}
              >
                <img
                  src={
                    d.image_url ||
                    `https://picsum.photos/seed/city${d.id || i}/300/200`
                  }
                  alt={d.name}
                  style={{
                    width: "100%",
                    height: 140,
                    objectFit: "cover",
                    display: "block",
                  }}
                  onError={(e) => {
                    e.target.src = `https://picsum.photos/seed/city${i}/300/200`;
                  }}
                />
                <div
                  style={{
                    position: "absolute",
                    bottom: 0,
                    left: 0,
                    right: 0,
                    background:
                      "linear-gradient(transparent, rgba(0,0,0,0.75))",
                    color: "#fff",
                    padding: "24px 10px 10px",
                  }}
                >
                  <div style={{ fontWeight: 700, fontSize: 14 }}>{d.name}</div>
                  {d.variants > 0 && (
                    <div style={{ fontSize: 12, opacity: 0.85 }}>
                      {d.variants.toLocaleString("ru-RU")} вариантов
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
}
