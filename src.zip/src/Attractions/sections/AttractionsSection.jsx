import { useQuery } from "react-query";
import { useNavigate } from "react-router-dom";
import { getAttractions, getAttractionCityByName } from "../api/attractions.js";

function formatPrice(price) {
  if (!price || price === 0) return "Бесплатно";
  return new Intl.NumberFormat("ru-RU").format(price) + " сум";
}

export default function AttractionsSection() {
  const navigate = useNavigate();
  const { data: attractions = [], isLoading } = useQuery(
    "attractions",
    () => getAttractions({ limit: 8 }),
    { staleTime: 5 * 60 * 1000 },
  );

  const openCityResults = (city) => {
    if (!city) {
      navigate("/attractions");
      return;
    }

    const cityMeta = getAttractionCityByName(city);
    navigate(cityMeta ? `/attractions/${cityMeta.slug}` : "/attractions/all");
  };

  return (
    <section style={{ padding: "32px 0" }}>
      <div className="site-container">
        {/* Заголовок */}
        <div className="attractions-header">
          <div>
            <h2
              style={{
                fontSize: 20,
                fontWeight: 700,
                color: "#1a1a1a",
                margin: 0,
              }}
            >
              Достопримечательности и развлечения
            </h2>
            <p
              style={{
                fontSize: 14,
                color: "#595959",
                marginTop: 4,
                marginBottom: 0,
              }}
            >
              Откройте лучшие места рядом с вашим жильём
            </p>
          </div>
          <button
            onClick={() => navigate("/attractions")}
            style={{
              fontSize: 14,
              fontWeight: 600,
              color: "#0071c2",
              background: "none",
              border: "none",
              cursor: "pointer",
              whiteSpace: "nowrap",
            }}
          >
            Посмотреть все
          </button>
        </div>

        {/* Карточки */}
        <div className="attractions-grid">
          {isLoading
            ? Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  style={{
                    borderRadius: 12,
                    overflow: "hidden",
                    background: "#f0f0f0",
                    paddingBottom: "75%",
                  }}
                />
              ))
            : attractions.map((item) => (
                <div
                  key={item.id}
                  onClick={() => openCityResults(item.city)}
                  style={{
                    borderRadius: 12,
                    overflow: "hidden",
                    border: "1px solid #e7e7e7",
                    cursor: "pointer",
                    background: "#fff",
                    transition: "box-shadow 0.2s",
                  }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.boxShadow =
                      "0 4px 16px rgba(0,0,0,0.12)")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.boxShadow = "none")
                  }
                >
                  {/* Изображение */}
                  <div
                    style={{
                      position: "relative",
                      paddingBottom: "75%",
                      background: "#f0f0f0",
                      overflow: "hidden",
                    }}
                  >
                    <img
                      src={item.image_url}
                      alt={item.name}
                      style={{
                        position: "absolute",
                        inset: 0,
                        width: "100%",
                        height: "100%",
                        objectFit: "cover",
                      }}
                      loading="lazy"
                    />
                    {/* Категория */}
                    <span
                      style={{
                        position: "absolute",
                        top: 8,
                        left: 8,
                        background: "rgba(255,255,255,0.92)",
                        color: "#1a1a1a",
                        fontSize: 11,
                        fontWeight: 500,
                        padding: "2px 8px",
                        borderRadius: 20,
                      }}
                    >
                      {item.category}
                    </span>
                  </div>

                  {/* Информация */}
                  <div style={{ padding: "10px 12px 12px" }}>
                    <h3
                      style={{
                        fontSize: 13,
                        fontWeight: 600,
                        color: "#1a1a1a",
                        margin: "0 0 4px",
                        lineHeight: 1.3,
                        display: "-webkit-box",
                        WebkitLineClamp: 2,
                        WebkitBoxOrient: "vertical",
                        overflow: "hidden",
                      }}
                    >
                      {item.name}
                    </h3>
                    <p
                      style={{
                        fontSize: 12,
                        color: "#595959",
                        margin: "0 0 8px",
                      }}
                    >
                      {item.city}, {item.country}
                    </p>

                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                      }}
                    >
                      {item.rating && (
                        <span
                          style={{
                            background: "#003580",
                            color: "#fff",
                            fontSize: 12,
                            fontWeight: 700,
                            padding: "2px 6px",
                            borderRadius: 4,
                          }}
                        >
                          {item.rating.toFixed(1)}
                        </span>
                      )}
                      <span
                        style={{
                          fontSize: 12,
                          fontWeight: 600,
                          color: "#0071c2",
                        }}
                      >
                        {formatPrice(item.price)}
                      </span>
                    </div>

                    {item.duration_hours && (
                      <p
                        style={{
                          fontSize: 12,
                          color: "#595959",
                          margin: "6px 0 0",
                        }}
                      >
                        ⏱ {item.duration_hours} ч
                      </p>
                    )}
                  </div>
                </div>
              ))}
        </div>
      </div>
    </section>
  );
}
