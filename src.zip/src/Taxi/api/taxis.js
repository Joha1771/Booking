import { supabase } from "../../lib/supabase.js";

export async function getTaxis() {
  const { data, error } = await supabase
    .from("airport_taxis")
    .select("*")
    .order("price", { ascending: true });

  if (error) console.error("getTaxis:", error.message);
  if (!data?.length) return getMockTaxis();

  return data.map((taxi) => ({
    ...taxi,
    image:
      taxi.image_url || `https://picsum.photos/seed/taxi_${taxi.id}/300/180`,
    price: taxi.price,
    perKm: null,
  }));
}

function getMockTaxis() {
  return [
    {
      id: 1,
      name: "Эконом",
      seats: 4,
      wait_time: "5-10 мин",
      price: 85000,
      perKm: 1200,
      description: "Доступный вариант для коротких поездок",
      image: "https://picsum.photos/seed/taxi1/300/180",
      free_cancel: true,
    },
    {
      id: 2,
      name: "Комфорт",
      seats: 4,
      wait_time: "3-7 мин",
      price: 140000,
      perKm: 1800,
      description: "Тихий и удобный автомобиль",
      image: "https://picsum.photos/seed/taxi2/300/180",
      free_cancel: true,
    },
    {
      id: 3,
      name: "Бизнес",
      seats: 4,
      wait_time: "7-12 мин",
      price: 250000,
      perKm: 3000,
      description: "Премиальный автомобиль для деловых поездок",
      image: "https://picsum.photos/seed/taxi3/300/180",
      free_cancel: true,
    },
    {
      id: 4,
      name: "Минивэн",
      seats: 7,
      wait_time: "10-15 мин",
      price: 180000,
      perKm: 2200,
      description: "Идеально для групп и семей",
      image: "https://picsum.photos/seed/taxi4/300/180",
      free_cancel: true,
    },
  ];
}
