import { useQuery } from "react-query";
import { getTaxis } from "../api/taxis.js";

export function useTaxis() {
  return useQuery(["taxis"], getTaxis, {
    staleTime: 10 * 60 * 1000,
    retry: 1,
  });
}
