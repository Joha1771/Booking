import { useNavigate } from "react-router-dom";

const FOOTER_SECTIONS = [
  {
    title: "Помощь",
    links: [
      { label: "Управлять поездками", path: "/profile" },
      { label: "Связаться с нами", path: "#" },
      { label: "Центр знаний по безопасности", path: "#" },
    ],
  },
  {
    title: "Разное",
    links: [
      { label: "Программа лояльности Genius", path: "#" },
      { label: "Сезонные и праздничные спецпредложения", path: "/search" },
      { label: "Статьи о путешествиях", path: "#" },
      { label: "Booking.com для бизнеса", path: "#" },
      { label: "Прокат автомобилей", path: "/cars" },
      { label: "Поиск авиабилетов", path: "/flights" },
      { label: "Заказ такси", path: "/taxi" },
    ],
  },
  {
    title: "Правила и настройки",
    links: [
      { label: "Положение о конфиденциальности", path: "#" },
      { label: "Условия предоставления услуг", path: "#" },
      { label: "Заявление о доступности", path: "#" },
      { label: "Разрешение споров", path: "#" },
    ],
  },
  {
    title: "Партнёрам",
    links: [
      { label: "Войти в Экстранет", path: "#" },
      { label: "Центр помощи партнёрам", path: "#" },
      { label: "Зарегистрировать свой объект", path: "#" },
      { label: "Программа для аффилиатов", path: "#" },
    ],
  },
  {
    title: "Компания",
    links: [
      { label: "О Booking.com", path: "#" },
      { label: "Как мы работаем", path: "#" },
      { label: "Устойчивое развитие", path: "#" },
      { label: "Пресс-центр", path: "#" },
      { label: "Вакансии", path: "#" },
    ],
  },
];

export default function Footer() {
  const navigate = useNavigate();

  const handleLink = (e, path) => {
    e.preventDefault();
    if (path && path !== "#") navigate(path);
  };

  return (
    <footer
      style={{
        background: "#fff",
        borderTop: "1px solid var(--booking-border)",
        marginTop: 16,
      }}
    >
      <div
        className="site-container"
        style={{ paddingTop: 32, paddingBottom: 32 }}
      >
        <div className="site-footer-grid">
          {FOOTER_SECTIONS.map((section, i) => (
            <div key={i}>
              <div className="footer-heading">{section.title}</div>
              <ul
                style={{
                  listStyle: "none",
                  display: "flex",
                  flexDirection: "column",
                  gap: 8,
                }}
              >
                {section.links.map((link, j) => (
                  <li key={j}>
                    <a
                      href={link.path}
                      onClick={(e) => handleLink(e, link.path)}
                      style={{
                        color: "var(--booking-blue-light)",
                        textDecoration: "none",
                        fontSize: 13,
                        lineHeight: 1.4,
                        cursor: "pointer",
                      }}
                      onMouseEnter={(e) =>
                        (e.currentTarget.style.textDecoration = "underline")
                      }
                      onMouseLeave={(e) =>
                        (e.currentTarget.style.textDecoration = "none")
                      }
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      <div style={{ borderTop: "1px solid var(--booking-border)" }}>
        <div
          className="site-container"
          style={{ paddingTop: 16, paddingBottom: 16 }}
        >
          <div className="site-footer-currency">
            <img
              src="https://flagcdn.com/20x15/uz.png"
              alt="UZ"
              style={{ width: 24, borderRadius: 2 }}
            />
            <span style={{ fontSize: 14, fontWeight: 600 }}>UZS</span>
          </div>
          <div
            style={{
              textAlign: "center",
              color: "var(--booking-text-light)",
              fontSize: 12,
              marginBottom: 12,
            }}
          >
            Booking.com — часть Booking Holdings Inc., мирового лидера в сфере
            онлайн-туризма и сопутствующих услуг.
            <br />
            Copyright © 1996–2026 Booking.com™. Все права защищены.
          </div>
          <div className="site-footer-brands">
            {["Booking.com", "priceline", "KAYAK", "agoda", "OpenTable"].map(
              (brand, i) => (
                <span
                  key={i}
                  style={{
                    fontSize: 14,
                    fontWeight: 700,
                    color:
                      i === 0
                        ? "var(--booking-blue)"
                        : "var(--booking-text-light)",
                  }}
                >
                  {brand}
                </span>
              ),
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
